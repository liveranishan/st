export class Course {
    CourseID:number;
    CourseName:string;
    StartDate:Date;
    EndDate:Date;
}
